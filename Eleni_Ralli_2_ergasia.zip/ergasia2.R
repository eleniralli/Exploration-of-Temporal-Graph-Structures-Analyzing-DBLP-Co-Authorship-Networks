library(igraph)


# Διαδρομή στα αρχεία CSV
path <- "D:/Gyqwinlinuxunix/home/eleni/yearly_data"


years <- c(2016, 2017, 2018, 2019, 2020)


# Φόρτωση των δεδομένων και αποθήκευση ως ξεχωριστά dataframes
df_2016 <- read.csv(file.path(path, "co_authorship_2016.csv"), header = TRUE)
df_2017 <- read.csv(file.path(path, "co_authorship_2017.csv"), header = TRUE)
df_2018 <- read.csv(file.path(path, "co_authorship_2018.csv"), header = TRUE)
df_2019 <- read.csv(file.path(path, "co_authorship_2019.csv"), header = TRUE)
df_2020 <- read.csv(file.path(path, "co_authorship_2020.csv"), header = TRUE)


print("Data frame for year 2016:")
print(head(df_2016))
print("Data frame for year 2017:")
print(head(df_2017))
print("Data frame for year 2018:")
print(head(df_2018))
print("Data frame for year 2019:")
print(head(df_2019))
print("Data frame for year 2020:")
print(head(df_2020))

str(df_2016)
str(df_2017)
str(df_2018)
str(df_2019)
str(df_2020)
#__________________________________________________________________________________________________
# 1: Δημιουργία των γραφημάτων igraph

# Διαδρομή στα αρχεία CSV
path <- "D:/Gyqwinlinuxunix/home/eleni/yearly_data"


# Δημιουργία γραφημάτων igraph και αποθήκευση σε αρχεία .rds
for (year in years) {
  file_name <- paste0(path, "/co_authorship_", year, ".csv")
  data <- read.csv(file_name, header = TRUE)

  # Δημιουργία γραφήματος με τα δεδομένα
  g <- graph_from_data_frame(d = data, directed = FALSE)

  # Αποθήκευση του γραφήματος σε αρχείο .rds
  saveRDS(g, file = paste0(path, "/graph_", year, ".rds"))


  print(paste("Graph for year", year, ":"))
  print(summary(g))
}

# Φόρτωση και οπτικοποίηση των γραφημάτων με μικρότερους κόμβους
for (year in years) {
  graph_file <- paste0(path, "/graph_", year, ".rds")
  g <- readRDS(graph_file)

  # Δημιουργία παραθύρου για την οπτικοποίηση του γραφήματος
  plot(g, main = paste("Co-authorship Graph for Year", year),
       vertex.size = 3, vertex.label = NA, edge.arrow.size = 0.5)
}

# Φάκελος για την αποθήκευση των εικόνων
output_path <- "D:/Gyqwinlinuxunix/home/eleni/graph_images"
dir.create(output_path, showWarnings = FALSE)

# Φόρτωση και αποθήκευση των γραφημάτων ως εικόνες
for (year in years) {
  graph_file <- paste0(path, "/graph_", year, ".rds")
  g <- readRDS(graph_file)

  # Αποθήκευση του γραφήματος ως εικόνα PNG
  png(filename = paste0(output_path, "/graph_", year, ".png"), width = 800, height = 600)
  plot(g, main = paste("Co-authorship Graph for Year", year),
       vertex.size = 5, vertex.label = NA, edge.arrow.size = 0.5)
  dev.off()
}

print("Graphs saved as PNG images in:")
print(output_path)


#_____________________________________________________________

# 2: Ανάλυση και Εξαγωγή Μετρήσεων

# Δημιουργία λιστών για να αποθηκεύσουμε τις μετρήσεις
num_vertices <- c()
num_edges <- c()
diameters <- c()
avg_degrees <- c()

# Ανάγνωση και ανάλυση γραφημάτων
for (year in years) {
  graph_file <- paste0(path, "/graph_", year, ".rds")
  g <- readRDS(graph_file)

  # Εξαγωγή μετρήσεων
  num_vertices <- c(num_vertices, vcount(g))
  num_edges <- c(num_edges, ecount(g))
  diameters <- c(diameters, diameter(g, directed = FALSE, unconnected = TRUE))
  avg_degrees <- c(avg_degrees, mean(degree(g)))
}

# Δημιουργία πίνακα με τα αποτελέσματα
metrics <- data.frame(
  Year = years,
  Num_Vertices = num_vertices,
  Num_Edges = num_edges,
  Diameter = diameters,
  Avg_Degree = avg_degrees
)

print(metrics)

# Φάκελος για την αποθήκευση των plots
output_path <- "D:/Gyqwinlinuxunix/home/eleni/plots"
dir.create(output_path, showWarnings = FALSE)

# Δημιουργία και αποθήκευση γραφημάτων
png(filename = paste0(output_path, "/metrics_plots.png"), width = 800, height = 800)

par(mfrow=c(2,2))

plot(years, num_vertices, type="b", main="Number of Vertices", xlab="Year", ylab="Count")
plot(years, num_edges, type="b", main="Number of Edges", xlab="Year", ylab="Count")
plot(years, diameters, type="b", main="Diameter", xlab="Year", ylab="Diameter")
plot(years, avg_degrees, type="b", main="Average Degree", xlab="Year", ylab="Average Degree")

dev.off()

print("Plots saved as PNG image in:")
print(output_path)
#_____________________________________________________________

# 3: Εύρεση Σημαντικών Κόμβων



# Δημιουργία λίστας για να αποθηκεύσουμε τους κορυφαίους κόμβους
top_nodes_degree <- list()
top_nodes_pagerank <- list()

# Ανάγνωση και ανάλυση γραφημάτων
for (year in years) {
  graph_file <- paste0(path, "/graph_", year, ".rds")
  g <- readRDS(graph_file)

  # Υπολογισμός βαθμού (degree) και PageRank
  degree_values <- degree(g, mode = "all")
  pagerank_values <- page_rank(g)$vector

  # Εύρεση κορυφαίων κόμβων
  top_degree <- sort(degree_values, decreasing = TRUE)[1:10]
  top_pagerank <- sort(pagerank_values, decreasing = TRUE)[1:10]

  # Αποθήκευση αποτελεσμάτων
  top_nodes_degree[[as.character(year)]] <- top_degree
  top_nodes_pagerank[[as.character(year)]] <- top_pagerank
}

# Εμφάνιση των κορυφαίων κόμβων για κάθε έτος
print("Top nodes by degree:")
print(top_nodes_degree)
print("Top nodes by PageRank:")
print(top_nodes_pagerank)


#__________________________________________________

#  4: Ανίχνευση Κοινοτήτων και Οπτικοποίηση

# Φόρτωση των γραφημάτων και ανίχνευση κοινοτήτων
graphs <- list(
  graph2016 = readRDS(file.path(path, "graph_2016.rds")),
  graph2017 = readRDS(file.path(path, "graph_2017.rds")),
  graph2018 = readRDS(file.path(path, "graph_2018.rds")),
  graph2019 = readRDS(file.path(path, "graph_2019.rds")),
  graph2020 = readRDS(file.path(path, "graph_2020.rds"))
)

# Απλοποίηση γραφημάτων για αφαίρεση πολλαπλών ακμών
graphs <- lapply(graphs, simplify)

# Ανίχνευση κοινοτήτων με Fast Greedy, Infomap και Louvain
detect_communities <- function(graph) {
  fast_greedy <- cluster_fast_greedy(graph)
  infomap <- cluster_infomap(graph)
  louvain <- cluster_louvain(graph)
  return(list(fast_greedy = fast_greedy, infomap = infomap, louvain = louvain))
}

communities <- lapply(graphs, detect_communities)

# Εμφάνιση του πλήθους κοινοτήτων για κάθε μέθοδο
community_sizes <- sapply(communities, function(comm) {
  c(
    fast_greedy = length(comm$fast_greedy),
    infomap = length(comm$infomap),
    louvain = length(comm$louvain)
  )
})
print(community_sizes)

# Επιλογή τυχαίου συγγραφέα που εμφανίζεται σε όλα τα έτη
common_authors <- Reduce(intersect, lapply(graphs, V))
set.seed(123)
random_author <- sample(common_authors, 1)

# Παρακολούθηση της εξέλιξης της κοινότητας του τυχαίου συγγραφέα
find_community <- function(communities, author) {
  sapply(communities, function(comm) {
    list(
      fast_greedy = membership(comm$fast_greedy)[author],
      infomap = membership(comm$infomap)[author],
      louvain = membership(comm$louvain)[author]
    )
  })
}

community_evolution <- find_community(communities, random_author)
print(community_evolution)

# Επιλογή Louvain clustering για την οπτικοποίηση
# Δημιουργία και αποθήκευση γραφημάτων για κάθε μέθοδο
output_path <- "D:/Gyqwinlinuxunix/home/eleni/graph_images"
dir.create(output_path, showWarnings = FALSE)

visualize_communities <- function(graph, community, year, method) {
  V(graph)$color <- factor(membership(community))
  is_crossing <- crossing(graph, communities = community)
  E(graph)$lty <- ifelse(is_crossing, "solid", "dotted")
  community_size <- sizes(community)
  in_mid_community <- unlist(community[community_size > 50 & community_size < 90])
  subgraph <- induced_subgraph(graph, in_mid_community)
  png(filename = paste0(output_path, "/graph_", year, "_", method, ".png"), width = 800, height = 600)
  plot(subgraph, vertex.size = 2, vertex.label = NA, edge.arrow.width = 0.8, edge.arrow.size = 0.2, main = paste("Communities in", year, "using", method))
  dev.off()
}

# Οπτικοποίηση του γραφήματος για κάθε έτος χρησιμοποιώντας Louvain
for (year in names(graphs)) {
  visualize_communities(graphs[[year]], communities[[year]]$louvain, year, "louvain")
}

print("Community graphs saved as PNG images in:")
print(output_path)
